# BbopZOO 관람객·직원·환경 시트 13장

계절 관람객 4장 / 직원 1장 / 계절 타일 4장 / 울타리 1장 / 장식 2장 / 시설·입구 1장.
요청 파일명과 폴더 분류를 유지했습니다. 총 318칸의 요청 순서표를 포함합니다.

## 파일 위치
- 원본 PNG: assets/spritesheets16/world/ (people, staff, tiles, fences, decor, facilities)
- 시트별 안내: assets/spritesheets16/world/README.md
- 순서·계절·행/열·A/B 구분: assets/catalog16_world.json
- 원본 명세: docs/briefs/world16-spec.json
- 기본 제작 문구: art-source/world16/prompts/
- 검수 기록: reports/WORLD16_SOURCE_REVIEW.md
- 기계 측정: reports/WORLD16_SOURCE_AUDIT.json

## 원본 상태
8장은 요청 캔버스와 일치합니다. 계절 타일 4장은 1254×1254(요청 1024×1024),
울타리는 1774×887(요청 1536×768)입니다.
정확한 네이티브 격자, 38색 팔레트, #FF00FF 배경, A/B 보행과 타일/울타리 연결성은
게임용 완성 검수에서 HOLD입니다. 개별 스프라이트 PNG를 추출하거나 코드로 이미지를 보정하지 않았습니다.
봄을 참조해 계절 관람객과 타일을 편집했고, 가을 옷 색 차이 및 겨울 봄꽃 잔류를 수정했습니다.

이 ZIP에는 이번 13장만 들어 있습니다. 이전 동물 12장과 8×8 자산, 게임 실행 코드는 별도입니다.
저장소: https://github.com/kelsnity86-arch/gotzoo
