# GOTZOO 스프라이트 묶음

시트 19장, 개별 원본 197개와 제작·검증 소스입니다.

- 전체 안내: ART_ASSETS.md
- 완성 시트: assets/spritesheets/
- 개별 원본: assets/sprites/
- 좌표·크기 목록: assets/catalog.json
- 제작 지시 원문: docs/briefs/

동물 등급과 자산 종류별 폴더를 유지했습니다. 배경은 요청 규격인 #FF00FF이며, 게임 연결 시 컬러 키로 제거하세요.

게임 실행 코드는 포함하지 않은 아트 자료 묶음입니다.
원본 저장소: https://github.com/kelsnity86-arch/gotzoo
원본 커밋: 611388baa7a58043ca22683cc7ee9d7d9cdecaad
