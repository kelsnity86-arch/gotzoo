# BbopZOO 동물 300종 — 생성 원본 ZIP

12장: animals16_01.png ~ animals16_12.png
상시 250종 + 봄·여름·가을·겨울 한정 50종

## 위치
- 원본 시트: assets/spritesheets16/animals/permanent/ (1~10)
- 계절 시트: assets/spritesheets16/animals/seasonal/ (11~12)
- 전체 안내: assets/spritesheets16/README.md
- 300종 순서·행/열·등급·계절: assets/catalog16.json
- 제작 명세: docs/briefs/animals16-spec.json
- 기본 제작 문구: art-source/animals16/prompts/
- 검수: reports/ANIMALS16_SOURCE_REVIEW.md / ANIMALS16_SOURCE_AUDIT.json

## 실제 파일 규격
원본 PNG는 모두 1254×1254입니다. 요청한 1024×1024 및 개별 16×16 격자,
정확한 38색 팔레트·#FF00FF 배경은 아직 충족하지 못했습니다.
정확한 픽셀 규격 검수는 HOLD이며, 게임용 완성 PNG라고 표시하지 않습니다.
이미지 생성 원본 바이트를 그대로 담았습니다. 개별 동물 추출·격자·팔레트 정리가 남아 있습니다.

이번 사용자 메시지에서 지정한 동물 12장 묶음입니다. 관람객·시설·UI 등 나머지 19장과
게임 실행 코드는 포함하지 않습니다. 기존 8×8 ZIP과 별개입니다.

저장소: https://github.com/kelsnity86-arch/gotzoo
